package com.example.quicklynote

data class Note(
    val content: String
)