package com.example.quicklynote

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.quicklynote.ui.theme.QuicklyNoteTheme

// MainActivity kế thừa từ ComponentActivity
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // Thiết lập chế độ edge-to-edge

        // Thiết lập nội dung cho MainActivity
        setContent {
            QuicklyNoteTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    NotesScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

// Composable để hiển thị giao diện ghi chú
@Composable
fun NotesScreen(modifier: Modifier = Modifier) {
    var notes by remember { mutableStateOf(listOf<Note>()) } // Danh sách ghi chú
    var noteText by remember { mutableStateOf("") } // Nội dung ghi chú đang nhập

    // Cấu trúc Column để bố trí các thành phần
    Column(modifier = modifier.padding(16.dp)) {
        // TextField để nhập ghi chú
        TextField(
            value = noteText,
            onValueChange = { noteText = it }, // Cập nhật nội dung
            label = { Text("Nhập ghi chú của bạn") }, // Nhãn cho TextField
            modifier = Modifier.fillMaxWidth() // Đầy chiều rộng
        )
        Spacer(modifier = Modifier.height(8.dp)) // Khoảng cách giữa các thành phần
        // Nút thêm ghi chú
        Button(onClick = {
            if (noteText.isNotBlank()) { // Kiểm tra nội dung
                notes = notes + Note(noteText) // Thêm ghi chú vào danh sách
                noteText = "" // Xóa nội dung trong TextField
            }
        }) {
            Text("Thêm Ghi Chú") // Nội dung của nút
        }
        Spacer(modifier = Modifier.height(16.dp)) // Khoảng cách
        // Hiển thị danh sách ghi chú
        Column {
            notes.forEach { note ->
                Text(text = note.content, modifier = Modifier.padding(4.dp)) // Hiển thị ghi chú
            }
        }
    }
}

// Preview cho NotesScreen
@Preview(showBackground = true)
@Composable
fun NotesScreenPreview() {
    QuicklyNoteTheme {
        NotesScreen()
    }
}